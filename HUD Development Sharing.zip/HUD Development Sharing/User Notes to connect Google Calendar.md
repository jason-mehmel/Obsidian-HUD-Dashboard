Calendar:
This plugin integrates with your google account to show your calendar.

Using this plugin can be somewhat involved, so I'll link to their setup instructions: https://yukigasai.github.io/obsidian-google-calendar/Setup (The first step of installing the Obsidian plugin should already be done in this vault.)

If this is too cumbersome, consider just writing a list of any major appointments in that window!

(You could also design or find a template for day tracking and structure it even further. There may also be other non-google calendar plugins to play with!)