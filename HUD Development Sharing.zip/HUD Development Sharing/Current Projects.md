(An example, feel free to make your own)
***Major Area 1*** (your job maybe)
List of things that need to get done this week or ASAP
Not everything in your job! Next week or two!

**Major Area 2** (hobby, second job, major project)

**ETC*

**Personal**
List of important goals, home or Habit1 related


Instructions on [[How To Use This Vault]]
also: [[User Notes to change the habit listings]]
also: [[User Notes to connect Google Calendar]]