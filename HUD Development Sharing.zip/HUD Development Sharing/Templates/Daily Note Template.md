
## Habits

**Work-Projects**:: (list the main projects you worked on)

- [ ] Habit1
- [ ] Habit2
- [ ] Habit3
- [ ] Habit4
- [ ] Habit5
- [ ] Habit6
- [ ] Habit7
- [ ] Work1
- [ ] Work2

## Notes




