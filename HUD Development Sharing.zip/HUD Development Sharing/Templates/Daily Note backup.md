
# [[<% tp.file.title %>|<% moment(tp.file.title).format("MMMM Do, YYYY") %>]]

[[<% tp.date.yesterday("YYYY-MM-DD") %>]] | [[<% tp.date.tomorrow("YYYY-MM-DD") %>]]

## Habits

**Reading**::
**Sleep**:: 0
**Exercise**:: 0
**Highlights**:: 0
**Mindfulness**:: 0

#exercise-pushup:

- [ ] exercisepushup

- [ ] Meditation




## Notes




