(comparing complete vs incomplete habits for the last 30 days of Daily notes)
--- start-multi-column: Top Level
```column-settings
number of columns: 3
border: off
```

Habit1

```dataviewjs
const stringToFind = 'Habit1';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit1',
      'Uncomplete'
      ],
    hidden: true,
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4,
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  }
};  
  
window.renderChart(chartData, this.container);

this.container.style.width = '100px';
```


--- end-column ---

Habit2

```dataviewjs
const stringToFind = 'Habit2';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit2',
      'Uncomplete'
      ],
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  } 
};  
  
window.renderChart(chartData, this.container);
this.container.style.width = '100px';
```


--- end-column ---

Habit3

```dataviewjs
const stringToFind = 'Habit3';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit3',
      'Uncomplete'
      ],
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  } 
};  
  
window.renderChart(chartData, this.container);
this.container.style.width = '100px';
```


--- end-multi-column
______
--- start-multi-column: Middle Level
```column-settings
number of columns: 3
border: off
```

Habit4

```dataviewjs
const stringToFind = 'Habit4';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit4',
      'Uncomplete'
      ],
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  }
};  
  
window.renderChart(chartData, this.container);
this.container.style.width = '100px';
```


--- end-column ---

Habit5

```dataviewjs
const stringToFind = 'Habit5';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit5',
      'Uncomplete'
      ],
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  } 
};  
  
window.renderChart(chartData, this.container);
this.container.style.width = '100px';
```


--- end-column ---

Habit6

```dataviewjs
const stringToFind = 'Habit6';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit6',
      'Uncomplete'
      ],
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  } 
};  
  
window.renderChart(chartData, this.container);
this.container.style.width = '100px';
```

--- end-multi-column 
______
--- start-multi-column: Bottom Level
```column-settings
number of columns: 3
border: off
```

Habit7

```dataviewjs
const stringToFind = 'Habit7';
// change to your query source(s)
const sources = '"Daily notes"';
const tasks = dv.pages(sources)
    .where((p) => dv.date("today").diff(dv.date(p.file.name)).as("days") <= 30)
    .file.tasks
        .where((t) => t.text.includes(stringToFind));
const completed = tasks.where((t) => t.completed).length;
const total = tasks.length;
const uncomplete = completed - total

const chartData = {  
  type: 'doughnut',  
  data: {  
    labels: [
      'Habit7',
      'Uncomplete'
      ],
	datasets: [{  
    data: [completed, uncomplete],
	 backgroundColor: [
      '#4daf4a',
      '#991515',
    ],
    hoverOffset: 4
    }],  
  },
  options: {
    plugins: {
      legend: {
        display: false,
      },
    },
    responsive: true
  } 
};  
  
window.renderChart(chartData, this.container);
this.container.style.width = '100px';
```

--- end-multi-column 