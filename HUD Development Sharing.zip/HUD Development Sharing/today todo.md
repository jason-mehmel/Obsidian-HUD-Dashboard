**Tomorrow**
(when something comes up today that you realise has to get done tomorrow, put it here)

**2025-01-23 13:31:31**
ctrl-shift-F5 creates a date and time stamp
(This uses the time stamper plugin)
Simple list of specific goals for today.
Not necessarily habits (I don't put them here)

**2025-01-22 17:56:56**
(accomplished tasks pushed downwards, generating a work log)
