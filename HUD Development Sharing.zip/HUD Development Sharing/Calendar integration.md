```gEvent
type: schedule
offset: 0
timespan: 3
showAllDay: false
navigation: true
```
