
```dataview
TABLE WITHOUT ID
  file.link as Date,
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit1"),
  "✅",
  "❌"
) AS "Habit1",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit2"),
  "✅",
  "❌"
) AS "Habit2",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit3"),
  "✅",
  "❌"
) AS "Habit3",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit4"),
  "✅",
  "❌"
) AS "Habit4",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit5"),
  "✅",
  "❌"
) AS "Habit5",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit6"),
  "✅",
  "❌"
) AS "Habit6",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Habit7"),
  "✅",
  "❌"
) AS "Habit7",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Work1"),
  "✅",
  "❌"
) AS "Work1",
choice(
  any(file.tasks, (t) => t.completed AND t.text = "Work2"),
  "✅",
  "❌"
) AS "Work2",
Work-Projects as Work-Projects
FROM "Daily notes"
WHERE file.day <= date(now) AND file.day >= date(now) - dur(30days)
SORT file.day DESC
```

