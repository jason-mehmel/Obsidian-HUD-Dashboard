(Want to change the listings to your own habits? Look here: [[User Notes to change the habit listings]] )

Instructions follow:

Click the last daily note on the left hand side, and then the Daily note button on the top left: (graphic) This will generate a new habit completion list for the day.

Hit ctrl-shift R: this will reset the vault and make sure the habit tracker table is up to date

As you satisfy your personal standard of completion for each goal, click on the task box to complete it.

On the 'today todo' and 'Current Projects' windows, simply type a list of goals for each day and projects for the week.

The Habit Tracker and Levels panes should update as you update your habits. (Or even just working in the vault, this is normal)

The [[today todo]], [[Waiting For]], and [[Current Projects]] pages don't affect the habit tracker or tables, they are simple text reminders!

If you want a bit more screen space, hit ctrl-P, type 'hider' and hit enter for 'toggle the tab bar'

Special thanks to sailKiteV for the dataviewjs assist with these charts!

Outside of these features, I can't promise any wisdom on advice for changes or other plugins! It may also take me some time to reply to any questions.

Thank you,

Jason Mehmel
jasonmehmel.com